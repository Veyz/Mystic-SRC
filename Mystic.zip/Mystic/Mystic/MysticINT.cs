﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Rainbow;
using System.Media;
using System.Threading;
using System.Runtime.InteropServices;
using System.Net;

namespace Mystic
{
    public partial class MysticINT : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,     // x-coordinate of upper-left corner
            int nTopRect,      // y-coordinate of upper-left corner
            int nRightRect,    // x-coordinate of lower-right corner
            int nBottomRect,   // y-coordinate of lower-right corner
            int nWidthEllipse, // height of ellipse
            int nHeightEllipse // width of ellipse
        );

        public MysticINT()
        {
            InitializeComponent();
            Directory.CreateDirectory(@"C:\Mystic\Scripts");
            this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));
            cxFlatTextArea1.Text = new WebClient().DownloadString("https://pastebin.com/raw/9ZRzfknh");
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            Class1.RainbowEffect();
            this.panel1.BackColor = Color.FromArgb(Class1.A, Class1.R, Class1.G);
            this.panel2.BackColor = Color.FromArgb(Class1.A, Class1.R, Class1.G);
            this.panel3.BackColor = Color.FromArgb(Class1.A, Class1.R, Class1.G);
            this.panel4.BackColor = Color.FromArgb(Class1.A, Class1.R, Class1.G);
        }

        private void DarkFlatButton1_Click(object sender, EventArgs e)
        {
            if (cxFlatCheckBox1.Checked)
            {
                byte[] myfile = Properties.Resources.TempCleaner;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\TempCleaner.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\TempCleaner.exe";
                pross.Start();
            }
            if (cxFlatCheckBox2.Checked)
            {
                byte[] myfile = Properties.Resources.NDUDisabler;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\NDUDisabler.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\NDUDisabler.exe";
                pross.Start();
            }
            if (cxFlatCheckBox3.Checked)
            {
                byte[] myfile = Properties.Resources.TelemetryCleaner;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\TelemetryCleaner.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\TelemetryCleaner.exe";
                pross.Start();

                using (StreamWriter w = File.AppendText(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "drivers/etc/hosts")))
                {
                    w.WriteLine("127.0.0.1 choice.microsoft.com");
                    w.WriteLine("127.0.0.1 choice.microsoft.com.nstac.net");
                    w.WriteLine("127.0.0.1 df.telemetry.microsoft.com");
                    w.WriteLine("127.0.0.1 oca.telemetry.microsoft.com");
                    w.WriteLine("127.0.0.1 oca.telemetry.microsoft.com.nsatc.net");
                    w.WriteLine("127.0.0.1 redir.metaservices.microsoft.com");
                    w.WriteLine("127.0.0.1 reports.wes.df.telemetry.microsoft.com");
                    w.WriteLine("127.0.0.1 services.wes.df.telemetry.microsoft.com");
                    w.WriteLine("127.0.0.1 settings-sandbox.data.microsoft.com");
                    w.WriteLine("127.0.0.1 settings-win.data.microsoft.com");
                    w.WriteLine("127.0.0.1 sqm.df.telemetry.microsoft.com");
                    w.WriteLine("127.0.0.1 sqm.telemetry.microsoft.com");
                    w.WriteLine("127.0.0.1 sqm.telemetry.microsoft.com.nsatc.net");
                    w.WriteLine("127.0.0.1 telecommand.telemetry.microsoft.com");
                    w.WriteLine("127.0.0.1 telecommand.telemetry.microsoft.com.nsatc.net");
                    w.WriteLine("127.0.0.1 telemetry.appex.bing.net");
                    w.WriteLine("127.0.0.1 telemetry.microsoft.com");
                    w.WriteLine("127.0.0.1 telemetry.urs.microsoft.com");
                    w.WriteLine("127.0.0.1 vortex-sandbox.data.microsoft.com");
                    w.WriteLine("127.0.0.1 vortex-win.data.microsoft.com");
                    w.WriteLine("127.0.0.1 vortex.data.microsoft.com");
                    w.WriteLine("127.0.0.1 watson.telemetry.microsoft.com");
                    w.WriteLine("127.0.0.1 watson.telemetry.microsoft.com.nsatc.net");
                    w.WriteLine("127.0.0.1 watson.ppe.telemetry.microsoft.com");
                    w.WriteLine("127.0.0.1 wes.df.telemetry.microsoft.com");
                    w.WriteLine("127.0.0.1 feedback.search.microsoft.com");
                    w.WriteLine("127.0.0.1 feedback.windows.com");
                }
            }
            if (cxFlatCheckBox4.Checked)
            {
                byte[] myfile = Properties.Resources.WindowsSettingsTweaker;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\WindowsSettingsTweaker.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\WindowsSettingsTweaker.exe";
                pross.Start();
            }
            if (cxFlatCheckBox5.Checked)
            {
                byte[] myfile = Properties.Resources.ServicesKiller;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\ServicesKiller.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\ServicesKiller.exe";
                pross.Start();
            }
            if (cxFlatCheckBox6.Checked)
            {
                byte[] myfile = Properties.Resources.NVIDIATelemetryDisabler;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\NVIDIATelemetryDisabler.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\NVIDIATelemetryDisabler.exe";
                pross.Start();
            }
            if (cxFlatCheckBox7.Checked)
            {
                byte[] myfile = Properties.Resources.AdTelemetryCleaner;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\AdTelemetryCleaner.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\AdTelemetryCleaner.exe";
                pross.Start();
            }
            if (cxFlatCheckBox8.Checked)
            {
                byte[] myfile = Properties.Resources.ConfidentialityCleaner;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\ConfidentialityCleaner.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\ConfidentialityCleaner.exe";
                pross.Start();
            }
            if (cxFlatCheckBox9.Checked)
            {
                byte[] myfile = Properties.Resources.DisableSleepMode;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\DisableSleepMode.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\DisableSleepMode.exe";
                pross.Start();
            }
            if (cxFlatComboBox1.SelectedText == "4 GB")
            {
                byte[] myfile = Properties.Resources._4GB;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\4GB.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\4GB.exe";
                pross.Start();
            }
            if (cxFlatComboBox1.SelectedText == "6 GB")
            {
                byte[] myfile = Properties.Resources._6GB;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\6GB.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\6GB.exe";
                pross.Start();
            }
            if (cxFlatComboBox1.SelectedText == "8 GB")
            {
                byte[] myfile = Properties.Resources._8GB;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\8GB.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\8GB.exe";
                pross.Start();
            }
            if (cxFlatComboBox1.SelectedText == "12 GB")
            {
                byte[] myfile = Properties.Resources._12GB;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\12GB.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\12GB.exe";
                pross.Start();
            }
            if (cxFlatComboBox1.SelectedText == "16 GB")
            {
                byte[] myfile = Properties.Resources._16GB;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\16GB.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\16GB.exe";
                pross.Start();
            }
            if (cxFlatComboBox1.SelectedText == "24 GB")
            {
                byte[] myfile = Properties.Resources._24GB;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\24GB.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\24GB.exe";
                pross.Start();
            }
            if (cxFlatComboBox1.SelectedText == "32 GB")
            {
                byte[] myfile = Properties.Resources._32GB;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\32GB.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\32GB.exe";
                pross.Start();
            }
            if (cxFlatComboBox1.SelectedText == "64 GB")
            {
                byte[] myfile = Properties.Resources._64GB;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\64GB.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\64GB.exe";
                pross.Start();
            }
            if (cxFlatCheckBox10.Checked)
            {
                byte[] myfile = Properties.Resources.WindowsELC;
                File.WriteAllBytes("C:\\Mystic\\Scripts\\WindowsELC.exe", myfile);
                Process pross = new Process();
                pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\WindowsELC.exe";
                pross.Start();
            }
        }

        private void DarkFlatButton2_Click(object sender, EventArgs e)
        {
            byte[] myfile = Properties.Resources.DisableUAC;
            File.WriteAllBytes("C:\\Mystic\\Scripts\\DisableUAC.exe", myfile);
            Process pross = new Process();
            pross.StartInfo.FileName = "C:\\Mystic\\Scripts\\DisableUAC.exe";
            pross.Start();
            Thread.Sleep(2000);
            MessageBox.Show("Votre PC va être redémarré :)", "Mystic | Infos", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Process.Start("shutdown", "/r /t 0");
        }

        private void PictureBox8_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://pastebin.com/raw/nR3BJmj2");
        }

        private void DarkFlatButton3_Click(object sender, EventArgs e)
        {
            cxFlatTextArea1.Text = new WebClient().DownloadString("https://pastebin.com/raw/9ZRzfknh");
        }

        private void PictureBox9_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://discord.gg/wU3JevJ");
        }

        private void PictureBox10_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://github.com/Veyz/Mystic-SRC");
        }
    }
}
