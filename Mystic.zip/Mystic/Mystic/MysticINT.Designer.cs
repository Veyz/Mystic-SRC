﻿namespace Mystic
{
    partial class MysticINT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MysticINT));
            this.cxFlatStatusBar1 = new CxFlatUI.CxFlatStatusBar();
            this.darkFlatTabControl1 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.darkFlatLabel7 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.darkFlatLabel6 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.darkFlatLabel5 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.darkFlatLabel4 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.darkFlatLabel3 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.darkFlatButton2 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatButton();
            this.darkFlatLabel28 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel27 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel26 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel25 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel24 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel23 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cxFlatCheckBox10 = new CxFlatUI.CxFlatCheckBox();
            this.darkFlatLabel35 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel34 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.cxFlatComboBox1 = new CxFlatUI.CxFlatComboBox();
            this.darkFlatLabel33 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cxFlatCheckBox9 = new CxFlatUI.CxFlatCheckBox();
            this.darkFlatLabel15 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.cxFlatCheckBox8 = new CxFlatUI.CxFlatCheckBox();
            this.darkFlatLabel14 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.cxFlatCheckBox7 = new CxFlatUI.CxFlatCheckBox();
            this.darkFlatLabel13 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.cxFlatCheckBox6 = new CxFlatUI.CxFlatCheckBox();
            this.darkFlatLabel12 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.cxFlatCheckBox5 = new CxFlatUI.CxFlatCheckBox();
            this.darkFlatLabel11 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.cxFlatCheckBox4 = new CxFlatUI.CxFlatCheckBox();
            this.darkFlatLabel10 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.cxFlatCheckBox3 = new CxFlatUI.CxFlatCheckBox();
            this.darkFlatLabel9 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatButton1 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatButton();
            this.cxFlatCheckBox2 = new CxFlatUI.CxFlatCheckBox();
            this.cxFlatCheckBox1 = new CxFlatUI.CxFlatCheckBox();
            this.darkFlatLabel8 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel2 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel1 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.darkFlatButton3 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatButton();
            this.cxFlatTextArea1 = new CxFlatUI.CxFlatTextArea();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.darkFlatLabel19 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel18 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel16 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.darkFlatLabel36 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel31 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel32 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel29 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.darkFlatLabel30 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.darkFlatLabel17 = new Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.darkFlatTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // cxFlatStatusBar1
            // 
            this.cxFlatStatusBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cxFlatStatusBar1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatStatusBar1.Location = new System.Drawing.Point(0, 0);
            this.cxFlatStatusBar1.Name = "cxFlatStatusBar1";
            this.cxFlatStatusBar1.Size = new System.Drawing.Size(920, 40);
            this.cxFlatStatusBar1.TabIndex = 0;
            this.cxFlatStatusBar1.Text = "Mystic | Clean & Privacy | Version : 1.6";
            this.cxFlatStatusBar1.ThemeColor = System.Drawing.Color.DodgerBlue;
            // 
            // darkFlatTabControl1
            // 
            this.darkFlatTabControl1.ActiveColor = System.Drawing.Color.DodgerBlue;
            this.darkFlatTabControl1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(53)))), ((int)(((byte)(66)))));
            this.darkFlatTabControl1.Controls.Add(this.tabPage1);
            this.darkFlatTabControl1.Controls.Add(this.tabPage4);
            this.darkFlatTabControl1.Controls.Add(this.tabPage2);
            this.darkFlatTabControl1.Controls.Add(this.tabPage5);
            this.darkFlatTabControl1.Controls.Add(this.tabPage3);
            this.darkFlatTabControl1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.darkFlatTabControl1.ItemSize = new System.Drawing.Size(120, 40);
            this.darkFlatTabControl1.Location = new System.Drawing.Point(0, 37);
            this.darkFlatTabControl1.Name = "darkFlatTabControl1";
            this.darkFlatTabControl1.SelectedIndex = 0;
            this.darkFlatTabControl1.Size = new System.Drawing.Size(920, 449);
            this.darkFlatTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.darkFlatTabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(53)))), ((int)(((byte)(66)))));
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.darkFlatLabel7);
            this.tabPage1.Controls.Add(this.pictureBox4);
            this.tabPage1.Controls.Add(this.darkFlatLabel6);
            this.tabPage1.Controls.Add(this.pictureBox3);
            this.tabPage1.Controls.Add(this.darkFlatLabel5);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Controls.Add(this.darkFlatLabel4);
            this.tabPage1.Controls.Add(this.pictureBox5);
            this.tabPage1.Controls.Add(this.darkFlatLabel3);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 44);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(912, 401);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Welcome";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Location = new System.Drawing.Point(-11, 389);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(941, 12);
            this.panel1.TabIndex = 15;
            // 
            // darkFlatLabel7
            // 
            this.darkFlatLabel7.AutoSize = true;
            this.darkFlatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel7.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel7.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel7.Location = new System.Drawing.Point(66, 275);
            this.darkFlatLabel7.Name = "darkFlatLabel7";
            this.darkFlatLabel7.Size = new System.Drawing.Size(331, 32);
            this.darkFlatLabel7.TabIndex = 14;
            this.darkFlatLabel7.Text = "Utilisation Rapide et Simple";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Mystic.Properties.Resources.Timer;
            this.pictureBox4.Location = new System.Drawing.Point(15, 268);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(45, 45);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // darkFlatLabel6
            // 
            this.darkFlatLabel6.AutoSize = true;
            this.darkFlatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel6.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel6.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel6.Location = new System.Drawing.Point(66, 224);
            this.darkFlatLabel6.Name = "darkFlatLabel6";
            this.darkFlatLabel6.Size = new System.Drawing.Size(162, 32);
            this.darkFlatLabel6.TabIndex = 12;
            this.darkFlatLabel6.Text = "Performance";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Mystic.Properties.Resources.Speed;
            this.pictureBox3.Location = new System.Drawing.Point(15, 217);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(45, 45);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            // 
            // darkFlatLabel5
            // 
            this.darkFlatLabel5.AutoSize = true;
            this.darkFlatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel5.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel5.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel5.Location = new System.Drawing.Point(66, 173);
            this.darkFlatLabel5.Name = "darkFlatLabel5";
            this.darkFlatLabel5.Size = new System.Drawing.Size(107, 32);
            this.darkFlatLabel5.TabIndex = 10;
            this.darkFlatLabel5.Text = "Sécurité";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Mystic.Properties.Resources.security;
            this.pictureBox2.Location = new System.Drawing.Point(15, 166);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(45, 45);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // darkFlatLabel4
            // 
            this.darkFlatLabel4.AutoSize = true;
            this.darkFlatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel4.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel4.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel4.Location = new System.Drawing.Point(66, 119);
            this.darkFlatLabel4.Name = "darkFlatLabel4";
            this.darkFlatLabel4.Size = new System.Drawing.Size(205, 32);
            this.darkFlatLabel4.TabIndex = 8;
            this.darkFlatLabel4.Text = "Anti-Espionnage";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Mystic.Properties.Resources.spy;
            this.pictureBox5.Location = new System.Drawing.Point(15, 112);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(45, 45);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // darkFlatLabel3
            // 
            this.darkFlatLabel3.AutoSize = true;
            this.darkFlatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel3.Font = new System.Drawing.Font("Segoe UI", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel3.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel3.Location = new System.Drawing.Point(8, 44);
            this.darkFlatLabel3.Name = "darkFlatLabel3";
            this.darkFlatLabel3.Size = new System.Drawing.Size(193, 37);
            this.darkFlatLabel3.TabIndex = 6;
            this.darkFlatLabel3.Text = "Nos Services :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Mystic.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(608, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(246, 275);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(53)))), ((int)(((byte)(66)))));
            this.tabPage4.Controls.Add(this.panel4);
            this.tabPage4.Controls.Add(this.darkFlatButton2);
            this.tabPage4.Controls.Add(this.darkFlatLabel28);
            this.tabPage4.Controls.Add(this.darkFlatLabel27);
            this.tabPage4.Controls.Add(this.darkFlatLabel26);
            this.tabPage4.Controls.Add(this.darkFlatLabel25);
            this.tabPage4.Controls.Add(this.darkFlatLabel24);
            this.tabPage4.Controls.Add(this.darkFlatLabel23);
            this.tabPage4.Location = new System.Drawing.Point(4, 44);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(912, 401);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Prérequis ";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel4.Location = new System.Drawing.Point(-11, 389);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(947, 12);
            this.panel4.TabIndex = 23;
            // 
            // darkFlatButton2
            // 
            this.darkFlatButton2.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatButton2.BaseColor = System.Drawing.Color.DodgerBlue;
            this.darkFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.darkFlatButton2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatButton2.Location = new System.Drawing.Point(353, 276);
            this.darkFlatButton2.Name = "darkFlatButton2";
            this.darkFlatButton2.Rounded = true;
            this.darkFlatButton2.Size = new System.Drawing.Size(206, 83);
            this.darkFlatButton2.TabIndex = 22;
            this.darkFlatButton2.Text = "Patch !  :D";
            this.darkFlatButton2.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.darkFlatButton2.Click += new System.EventHandler(this.DarkFlatButton2_Click);
            // 
            // darkFlatLabel28
            // 
            this.darkFlatLabel28.AutoSize = true;
            this.darkFlatLabel28.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel28.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel28.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel28.Location = new System.Drawing.Point(10, 178);
            this.darkFlatLabel28.Name = "darkFlatLabel28";
            this.darkFlatLabel28.Size = new System.Drawing.Size(837, 25);
            this.darkFlatLabel28.TabIndex = 21;
            this.darkFlatLabel28.Text = "Votre Pc Redémarrera par la Suite et vous Pourrez Commencer votre Optimisation Wi" +
    "ndows !";
            // 
            // darkFlatLabel27
            // 
            this.darkFlatLabel27.AutoSize = true;
            this.darkFlatLabel27.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel27.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel27.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel27.Location = new System.Drawing.Point(10, 142);
            this.darkFlatLabel27.Name = "darkFlatLabel27";
            this.darkFlatLabel27.Size = new System.Drawing.Size(706, 25);
            this.darkFlatLabel27.TabIndex = 20;
            this.darkFlatLabel27.Text = "de scripts :(   Pour réaliser les prérequis vous avez juste à cliquer sur ce bout" +
    "on";
            // 
            // darkFlatLabel26
            // 
            this.darkFlatLabel26.AutoSize = true;
            this.darkFlatLabel26.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel26.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel26.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel26.Location = new System.Drawing.Point(121, 105);
            this.darkFlatLabel26.Name = "darkFlatLabel26";
            this.darkFlatLabel26.Size = new System.Drawing.Size(754, 25);
            this.darkFlatLabel26.TabIndex = 19;
            this.darkFlatLabel26.Text = "Si vous ne faites pas cette étape vous pourrez avoir des Blue Screens où des erre" +
    "urs ";
            // 
            // darkFlatLabel25
            // 
            this.darkFlatLabel25.AutoSize = true;
            this.darkFlatLabel25.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel25.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel25.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel25.Location = new System.Drawing.Point(10, 105);
            this.darkFlatLabel25.Name = "darkFlatLabel25";
            this.darkFlatLabel25.Size = new System.Drawing.Size(114, 25);
            this.darkFlatLabel25.TabIndex = 18;
            this.darkFlatLabel25.Text = "des scripts .";
            // 
            // darkFlatLabel24
            // 
            this.darkFlatLabel24.AutoSize = true;
            this.darkFlatLabel24.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel24.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel24.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel24.Location = new System.Drawing.Point(10, 71);
            this.darkFlatLabel24.Name = "darkFlatLabel24";
            this.darkFlatLabel24.Size = new System.Drawing.Size(838, 25);
            this.darkFlatLabel24.TabIndex = 17;
            this.darkFlatLabel24.Text = "Veillez absolument  faire ce prérequis si vous ne voulez pas avoir d\'erreurs lors" +
    " de l\'exécution";
            // 
            // darkFlatLabel23
            // 
            this.darkFlatLabel23.AutoSize = true;
            this.darkFlatLabel23.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel23.Font = new System.Drawing.Font("Segoe UI", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel23.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel23.Location = new System.Drawing.Point(8, 16);
            this.darkFlatLabel23.Name = "darkFlatLabel23";
            this.darkFlatLabel23.Size = new System.Drawing.Size(153, 37);
            this.darkFlatLabel23.TabIndex = 8;
            this.darkFlatLabel23.Text = "Prérequis :";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(53)))), ((int)(((byte)(66)))));
            this.tabPage2.Controls.Add(this.cxFlatCheckBox10);
            this.tabPage2.Controls.Add(this.darkFlatLabel35);
            this.tabPage2.Controls.Add(this.darkFlatLabel34);
            this.tabPage2.Controls.Add(this.pictureBox8);
            this.tabPage2.Controls.Add(this.cxFlatComboBox1);
            this.tabPage2.Controls.Add(this.darkFlatLabel33);
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.cxFlatCheckBox9);
            this.tabPage2.Controls.Add(this.darkFlatLabel15);
            this.tabPage2.Controls.Add(this.pictureBox6);
            this.tabPage2.Controls.Add(this.cxFlatCheckBox8);
            this.tabPage2.Controls.Add(this.darkFlatLabel14);
            this.tabPage2.Controls.Add(this.cxFlatCheckBox7);
            this.tabPage2.Controls.Add(this.darkFlatLabel13);
            this.tabPage2.Controls.Add(this.cxFlatCheckBox6);
            this.tabPage2.Controls.Add(this.darkFlatLabel12);
            this.tabPage2.Controls.Add(this.cxFlatCheckBox5);
            this.tabPage2.Controls.Add(this.darkFlatLabel11);
            this.tabPage2.Controls.Add(this.cxFlatCheckBox4);
            this.tabPage2.Controls.Add(this.darkFlatLabel10);
            this.tabPage2.Controls.Add(this.cxFlatCheckBox3);
            this.tabPage2.Controls.Add(this.darkFlatLabel9);
            this.tabPage2.Controls.Add(this.darkFlatButton1);
            this.tabPage2.Controls.Add(this.cxFlatCheckBox2);
            this.tabPage2.Controls.Add(this.cxFlatCheckBox1);
            this.tabPage2.Controls.Add(this.darkFlatLabel8);
            this.tabPage2.Controls.Add(this.darkFlatLabel2);
            this.tabPage2.Controls.Add(this.darkFlatLabel1);
            this.tabPage2.Location = new System.Drawing.Point(4, 44);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(912, 401);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Cleaner";
            // 
            // cxFlatCheckBox10
            // 
            this.cxFlatCheckBox10.AutoSize = true;
            this.cxFlatCheckBox10.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox10.Location = new System.Drawing.Point(289, 316);
            this.cxFlatCheckBox10.Name = "cxFlatCheckBox10";
            this.cxFlatCheckBox10.Size = new System.Drawing.Size(25, 20);
            this.cxFlatCheckBox10.TabIndex = 41;
            this.cxFlatCheckBox10.UseVisualStyleBackColor = true;
            // 
            // darkFlatLabel35
            // 
            this.darkFlatLabel35.AutoSize = true;
            this.darkFlatLabel35.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel35.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel35.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel35.Location = new System.Drawing.Point(8, 311);
            this.darkFlatLabel35.Name = "darkFlatLabel35";
            this.darkFlatLabel35.Size = new System.Drawing.Size(275, 25);
            this.darkFlatLabel35.TabIndex = 40;
            this.darkFlatLabel35.Text = "Delete Windows Events Logs :";
            // 
            // darkFlatLabel34
            // 
            this.darkFlatLabel34.AutoSize = true;
            this.darkFlatLabel34.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel34.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel34.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel34.Location = new System.Drawing.Point(772, 11);
            this.darkFlatLabel34.Name = "darkFlatLabel34";
            this.darkFlatLabel34.Size = new System.Drawing.Size(81, 32);
            this.darkFlatLabel34.TabIndex = 39;
            this.darkFlatLabel34.Text = "Aide :";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox8.Image = global::Mystic.Properties.Resources.question;
            this.pictureBox8.Location = new System.Drawing.Point(858, 6);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(46, 44);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 38;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.PictureBox8_Click);
            // 
            // cxFlatComboBox1
            // 
            this.cxFlatComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cxFlatComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cxFlatComboBox1.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.cxFlatComboBox1.FormattingEnabled = true;
            this.cxFlatComboBox1.ItemHeight = 30;
            this.cxFlatComboBox1.Items.AddRange(new object[] {
            "4 GB",
            "6 GB",
            "8 GB",
            "12 GB",
            "16 GB",
            "24 GB",
            "32 GB",
            "64 GB"});
            this.cxFlatComboBox1.Location = new System.Drawing.Point(670, 141);
            this.cxFlatComboBox1.Name = "cxFlatComboBox1";
            this.cxFlatComboBox1.Size = new System.Drawing.Size(121, 36);
            this.cxFlatComboBox1.TabIndex = 37;
            // 
            // darkFlatLabel33
            // 
            this.darkFlatLabel33.AutoSize = true;
            this.darkFlatLabel33.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel33.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel33.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel33.Location = new System.Drawing.Point(636, 90);
            this.darkFlatLabel33.Name = "darkFlatLabel33";
            this.darkFlatLabel33.Size = new System.Drawing.Size(200, 32);
            this.darkFlatLabel33.TabIndex = 36;
            this.darkFlatLabel33.Text = "Ram Optimizer :";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel3.Location = new System.Drawing.Point(-11, 389);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(975, 12);
            this.panel3.TabIndex = 35;
            // 
            // cxFlatCheckBox9
            // 
            this.cxFlatCheckBox9.AutoSize = true;
            this.cxFlatCheckBox9.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox9.Location = new System.Drawing.Point(209, 291);
            this.cxFlatCheckBox9.Name = "cxFlatCheckBox9";
            this.cxFlatCheckBox9.Size = new System.Drawing.Size(25, 20);
            this.cxFlatCheckBox9.TabIndex = 28;
            this.cxFlatCheckBox9.UseVisualStyleBackColor = true;
            // 
            // darkFlatLabel15
            // 
            this.darkFlatLabel15.AutoSize = true;
            this.darkFlatLabel15.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel15.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel15.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel15.Location = new System.Drawing.Point(7, 286);
            this.darkFlatLabel15.Name = "darkFlatLabel15";
            this.darkFlatLabel15.Size = new System.Drawing.Size(196, 25);
            this.darkFlatLabel15.TabIndex = 27;
            this.darkFlatLabel15.Text = "Disable Sleep Mode :";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Mystic.Properties.Resources.settings;
            this.pictureBox6.Location = new System.Drawing.Point(503, 3);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(45, 45);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 26;
            this.pictureBox6.TabStop = false;
            // 
            // cxFlatCheckBox8
            // 
            this.cxFlatCheckBox8.AutoSize = true;
            this.cxFlatCheckBox8.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox8.Location = new System.Drawing.Point(323, 266);
            this.cxFlatCheckBox8.Name = "cxFlatCheckBox8";
            this.cxFlatCheckBox8.Size = new System.Drawing.Size(25, 20);
            this.cxFlatCheckBox8.TabIndex = 25;
            this.cxFlatCheckBox8.UseVisualStyleBackColor = true;
            // 
            // darkFlatLabel14
            // 
            this.darkFlatLabel14.AutoSize = true;
            this.darkFlatLabel14.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel14.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel14.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel14.Location = new System.Drawing.Point(6, 161);
            this.darkFlatLabel14.Name = "darkFlatLabel14";
            this.darkFlatLabel14.Size = new System.Drawing.Size(251, 25);
            this.darkFlatLabel14.TabIndex = 24;
            this.darkFlatLabel14.Text = "Windows Settings Tweaks :";
            // 
            // cxFlatCheckBox7
            // 
            this.cxFlatCheckBox7.AutoSize = true;
            this.cxFlatCheckBox7.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox7.Location = new System.Drawing.Point(263, 242);
            this.cxFlatCheckBox7.Name = "cxFlatCheckBox7";
            this.cxFlatCheckBox7.Size = new System.Drawing.Size(25, 20);
            this.cxFlatCheckBox7.TabIndex = 23;
            this.cxFlatCheckBox7.UseVisualStyleBackColor = true;
            // 
            // darkFlatLabel13
            // 
            this.darkFlatLabel13.AutoSize = true;
            this.darkFlatLabel13.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel13.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel13.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel13.Location = new System.Drawing.Point(7, 211);
            this.darkFlatLabel13.Name = "darkFlatLabel13";
            this.darkFlatLabel13.Size = new System.Drawing.Size(250, 25);
            this.darkFlatLabel13.TabIndex = 22;
            this.darkFlatLabel13.Text = "Disable NVIDIA Telemetry :";
            // 
            // cxFlatCheckBox6
            // 
            this.cxFlatCheckBox6.AutoSize = true;
            this.cxFlatCheckBox6.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox6.Location = new System.Drawing.Point(263, 216);
            this.cxFlatCheckBox6.Name = "cxFlatCheckBox6";
            this.cxFlatCheckBox6.Size = new System.Drawing.Size(25, 20);
            this.cxFlatCheckBox6.TabIndex = 21;
            this.cxFlatCheckBox6.UseVisualStyleBackColor = true;
            // 
            // darkFlatLabel12
            // 
            this.darkFlatLabel12.AutoSize = true;
            this.darkFlatLabel12.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel12.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel12.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel12.Location = new System.Drawing.Point(6, 186);
            this.darkFlatLabel12.Name = "darkFlatLabel12";
            this.darkFlatLabel12.Size = new System.Drawing.Size(231, 25);
            this.darkFlatLabel12.TabIndex = 20;
            this.darkFlatLabel12.Text = "Disable Useless Services :";
            // 
            // cxFlatCheckBox5
            // 
            this.cxFlatCheckBox5.AutoSize = true;
            this.cxFlatCheckBox5.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox5.Location = new System.Drawing.Point(263, 192);
            this.cxFlatCheckBox5.Name = "cxFlatCheckBox5";
            this.cxFlatCheckBox5.Size = new System.Drawing.Size(25, 20);
            this.cxFlatCheckBox5.TabIndex = 19;
            this.cxFlatCheckBox5.UseVisualStyleBackColor = true;
            // 
            // darkFlatLabel11
            // 
            this.darkFlatLabel11.AutoSize = true;
            this.darkFlatLabel11.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel11.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel11.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel11.Location = new System.Drawing.Point(7, 261);
            this.darkFlatLabel11.Name = "darkFlatLabel11";
            this.darkFlatLabel11.Size = new System.Drawing.Size(310, 25);
            this.darkFlatLabel11.TabIndex = 18;
            this.darkFlatLabel11.Text = "Windows Confidentiality Tweaks :";
            // 
            // cxFlatCheckBox4
            // 
            this.cxFlatCheckBox4.AutoSize = true;
            this.cxFlatCheckBox4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox4.Location = new System.Drawing.Point(263, 166);
            this.cxFlatCheckBox4.Name = "cxFlatCheckBox4";
            this.cxFlatCheckBox4.Size = new System.Drawing.Size(25, 20);
            this.cxFlatCheckBox4.TabIndex = 17;
            this.cxFlatCheckBox4.UseVisualStyleBackColor = true;
            // 
            // darkFlatLabel10
            // 
            this.darkFlatLabel10.AutoSize = true;
            this.darkFlatLabel10.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel10.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel10.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel10.Location = new System.Drawing.Point(6, 86);
            this.darkFlatLabel10.Name = "darkFlatLabel10";
            this.darkFlatLabel10.Size = new System.Drawing.Size(113, 25);
            this.darkFlatLabel10.TabIndex = 16;
            this.darkFlatLabel10.Text = "Temp Files :";
            // 
            // cxFlatCheckBox3
            // 
            this.cxFlatCheckBox3.AutoSize = true;
            this.cxFlatCheckBox3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox3.Location = new System.Drawing.Point(209, 141);
            this.cxFlatCheckBox3.Name = "cxFlatCheckBox3";
            this.cxFlatCheckBox3.Size = new System.Drawing.Size(25, 20);
            this.cxFlatCheckBox3.TabIndex = 15;
            this.cxFlatCheckBox3.UseVisualStyleBackColor = true;
            // 
            // darkFlatLabel9
            // 
            this.darkFlatLabel9.AutoSize = true;
            this.darkFlatLabel9.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel9.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel9.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel9.Location = new System.Drawing.Point(6, 111);
            this.darkFlatLabel9.Name = "darkFlatLabel9";
            this.darkFlatLabel9.Size = new System.Drawing.Size(134, 25);
            this.darkFlatLabel9.TabIndex = 14;
            this.darkFlatLabel9.Text = "Disable NDU :";
            // 
            // darkFlatButton1
            // 
            this.darkFlatButton1.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatButton1.BaseColor = System.Drawing.Color.DodgerBlue;
            this.darkFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.darkFlatButton1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.darkFlatButton1.Location = new System.Drawing.Point(777, 347);
            this.darkFlatButton1.Name = "darkFlatButton1";
            this.darkFlatButton1.Rounded = true;
            this.darkFlatButton1.Size = new System.Drawing.Size(129, 36);
            this.darkFlatButton1.TabIndex = 13;
            this.darkFlatButton1.Text = "Apply";
            this.darkFlatButton1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.darkFlatButton1.Click += new System.EventHandler(this.DarkFlatButton1_Click);
            // 
            // cxFlatCheckBox2
            // 
            this.cxFlatCheckBox2.AutoSize = true;
            this.cxFlatCheckBox2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox2.Location = new System.Drawing.Point(146, 116);
            this.cxFlatCheckBox2.Name = "cxFlatCheckBox2";
            this.cxFlatCheckBox2.Size = new System.Drawing.Size(25, 20);
            this.cxFlatCheckBox2.TabIndex = 12;
            this.cxFlatCheckBox2.UseVisualStyleBackColor = true;
            // 
            // cxFlatCheckBox1
            // 
            this.cxFlatCheckBox1.AutoSize = true;
            this.cxFlatCheckBox1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox1.Location = new System.Drawing.Point(146, 90);
            this.cxFlatCheckBox1.Name = "cxFlatCheckBox1";
            this.cxFlatCheckBox1.Size = new System.Drawing.Size(25, 20);
            this.cxFlatCheckBox1.TabIndex = 11;
            this.cxFlatCheckBox1.UseVisualStyleBackColor = true;
            // 
            // darkFlatLabel8
            // 
            this.darkFlatLabel8.AutoSize = true;
            this.darkFlatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel8.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel8.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel8.Location = new System.Drawing.Point(6, 236);
            this.darkFlatLabel8.Name = "darkFlatLabel8";
            this.darkFlatLabel8.Size = new System.Drawing.Size(252, 25);
            this.darkFlatLabel8.TabIndex = 10;
            this.darkFlatLabel8.Text = "Other Windows Telemetry :";
            // 
            // darkFlatLabel2
            // 
            this.darkFlatLabel2.AutoSize = true;
            this.darkFlatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel2.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel2.Location = new System.Drawing.Point(6, 136);
            this.darkFlatLabel2.Name = "darkFlatLabel2";
            this.darkFlatLabel2.Size = new System.Drawing.Size(197, 25);
            this.darkFlatLabel2.TabIndex = 8;
            this.darkFlatLabel2.Text = "Windows Telemetry :";
            // 
            // darkFlatLabel1
            // 
            this.darkFlatLabel1.AutoSize = true;
            this.darkFlatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel1.Font = new System.Drawing.Font("Segoe UI", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel1.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel1.Location = new System.Drawing.Point(365, 3);
            this.darkFlatLabel1.Name = "darkFlatLabel1";
            this.darkFlatLabel1.Size = new System.Drawing.Size(132, 37);
            this.darkFlatLabel1.TabIndex = 7;
            this.darkFlatLabel1.Text = "Options :";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(53)))), ((int)(((byte)(66)))));
            this.tabPage5.Controls.Add(this.darkFlatButton3);
            this.tabPage5.Controls.Add(this.cxFlatTextArea1);
            this.tabPage5.Location = new System.Drawing.Point(4, 44);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(912, 401);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "News";
            // 
            // darkFlatButton3
            // 
            this.darkFlatButton3.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatButton3.BaseColor = System.Drawing.Color.DodgerBlue;
            this.darkFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.darkFlatButton3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.darkFlatButton3.Location = new System.Drawing.Point(392, 356);
            this.darkFlatButton3.Name = "darkFlatButton3";
            this.darkFlatButton3.Rounded = true;
            this.darkFlatButton3.Size = new System.Drawing.Size(129, 36);
            this.darkFlatButton3.TabIndex = 14;
            this.darkFlatButton3.Text = "Refresh";
            this.darkFlatButton3.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.darkFlatButton3.Click += new System.EventHandler(this.DarkFlatButton3_Click);
            // 
            // cxFlatTextArea1
            // 
            this.cxFlatTextArea1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatTextArea1.Hint = "";
            this.cxFlatTextArea1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cxFlatTextArea1.Location = new System.Drawing.Point(3, 3);
            this.cxFlatTextArea1.MaxLength = 32767;
            this.cxFlatTextArea1.Multiline = true;
            this.cxFlatTextArea1.Name = "cxFlatTextArea1";
            this.cxFlatTextArea1.PasswordChar = '\0';
            this.cxFlatTextArea1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.cxFlatTextArea1.SelectedText = "";
            this.cxFlatTextArea1.SelectionLength = 0;
            this.cxFlatTextArea1.SelectionStart = 0;
            this.cxFlatTextArea1.Size = new System.Drawing.Size(906, 336);
            this.cxFlatTextArea1.TabIndex = 0;
            this.cxFlatTextArea1.TabStop = false;
            this.cxFlatTextArea1.UseSystemPasswordChar = false;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(53)))), ((int)(((byte)(66)))));
            this.tabPage3.Controls.Add(this.darkFlatLabel19);
            this.tabPage3.Controls.Add(this.darkFlatLabel18);
            this.tabPage3.Controls.Add(this.darkFlatLabel16);
            this.tabPage3.Controls.Add(this.pictureBox10);
            this.tabPage3.Controls.Add(this.pictureBox9);
            this.tabPage3.Controls.Add(this.darkFlatLabel36);
            this.tabPage3.Controls.Add(this.darkFlatLabel31);
            this.tabPage3.Controls.Add(this.darkFlatLabel32);
            this.tabPage3.Controls.Add(this.darkFlatLabel29);
            this.tabPage3.Controls.Add(this.darkFlatLabel30);
            this.tabPage3.Controls.Add(this.panel2);
            this.tabPage3.Controls.Add(this.pictureBox7);
            this.tabPage3.Controls.Add(this.darkFlatLabel17);
            this.tabPage3.Location = new System.Drawing.Point(4, 44);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(912, 401);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Infos";
            // 
            // darkFlatLabel19
            // 
            this.darkFlatLabel19.AutoSize = true;
            this.darkFlatLabel19.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel19.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel19.ForeColor = System.Drawing.Color.DodgerBlue;
            this.darkFlatLabel19.Location = new System.Drawing.Point(713, 223);
            this.darkFlatLabel19.Name = "darkFlatLabel19";
            this.darkFlatLabel19.Size = new System.Drawing.Size(59, 40);
            this.darkFlatLabel19.TabIndex = 44;
            this.darkFlatLabel19.Text = "1.6";
            // 
            // darkFlatLabel18
            // 
            this.darkFlatLabel18.AutoSize = true;
            this.darkFlatLabel18.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel18.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel18.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel18.Location = new System.Drawing.Point(523, 223);
            this.darkFlatLabel18.Name = "darkFlatLabel18";
            this.darkFlatLabel18.Size = new System.Drawing.Size(172, 40);
            this.darkFlatLabel18.TabIndex = 43;
            this.darkFlatLabel18.Text = "> Version : ";
            // 
            // darkFlatLabel16
            // 
            this.darkFlatLabel16.AutoSize = true;
            this.darkFlatLabel16.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel16.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel16.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel16.Location = new System.Drawing.Point(7, 227);
            this.darkFlatLabel16.Name = "darkFlatLabel16";
            this.darkFlatLabel16.Size = new System.Drawing.Size(200, 32);
            this.darkFlatLabel16.TabIndex = 42;
            this.darkFlatLabel16.Text = "GitHub ( SRC  ) :";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox10.Image = global::Mystic.Properties.Resources.GitHub;
            this.pictureBox10.Location = new System.Drawing.Point(213, 216);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(68, 64);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 41;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.PictureBox10_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox9.Image = global::Mystic.Properties.Resources.Discord;
            this.pictureBox9.Location = new System.Drawing.Point(213, 128);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(68, 64);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 40;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.PictureBox9_Click);
            // 
            // darkFlatLabel36
            // 
            this.darkFlatLabel36.AutoSize = true;
            this.darkFlatLabel36.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel36.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel36.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel36.Location = new System.Drawing.Point(17, 143);
            this.darkFlatLabel36.Name = "darkFlatLabel36";
            this.darkFlatLabel36.Size = new System.Drawing.Size(190, 32);
            this.darkFlatLabel36.TabIndex = 39;
            this.darkFlatLabel36.Text = "Notre Discord :";
            // 
            // darkFlatLabel31
            // 
            this.darkFlatLabel31.AutoSize = true;
            this.darkFlatLabel31.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel31.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel31.ForeColor = System.Drawing.Color.DodgerBlue;
            this.darkFlatLabel31.Location = new System.Drawing.Point(713, 183);
            this.darkFlatLabel31.Name = "darkFlatLabel31";
            this.darkFlatLabel31.Size = new System.Drawing.Size(109, 40);
            this.darkFlatLabel31.TabIndex = 38;
            this.darkFlatLabel31.Text = "Aspect";
            // 
            // darkFlatLabel32
            // 
            this.darkFlatLabel32.AutoSize = true;
            this.darkFlatLabel32.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel32.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel32.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel32.Location = new System.Drawing.Point(486, 183);
            this.darkFlatLabel32.Name = "darkFlatLabel32";
            this.darkFlatLabel32.Size = new System.Drawing.Size(209, 40);
            this.darkFlatLabel32.TabIndex = 37;
            this.darkFlatLabel32.Text = "> Co-Owner : ";
            // 
            // darkFlatLabel29
            // 
            this.darkFlatLabel29.AutoSize = true;
            this.darkFlatLabel29.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel29.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel29.ForeColor = System.Drawing.Color.DodgerBlue;
            this.darkFlatLabel29.Location = new System.Drawing.Point(713, 143);
            this.darkFlatLabel29.Name = "darkFlatLabel29";
            this.darkFlatLabel29.Size = new System.Drawing.Size(128, 40);
            this.darkFlatLabel29.TabIndex = 36;
            this.darkFlatLabel29.Text = "Krypted";
            // 
            // darkFlatLabel30
            // 
            this.darkFlatLabel30.AutoSize = true;
            this.darkFlatLabel30.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel30.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel30.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel30.Location = new System.Drawing.Point(572, 143);
            this.darkFlatLabel30.Name = "darkFlatLabel30";
            this.darkFlatLabel30.Size = new System.Drawing.Size(123, 40);
            this.darkFlatLabel30.TabIndex = 35;
            this.darkFlatLabel30.Text = "> Dev : ";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Location = new System.Drawing.Point(-11, 389);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(958, 12);
            this.panel2.TabIndex = 34;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Mystic.Properties.Resources.user;
            this.pictureBox7.Location = new System.Drawing.Point(536, 9);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(45, 45);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 27;
            this.pictureBox7.TabStop = false;
            // 
            // darkFlatLabel17
            // 
            this.darkFlatLabel17.AutoSize = true;
            this.darkFlatLabel17.BackColor = System.Drawing.Color.Transparent;
            this.darkFlatLabel17.Font = new System.Drawing.Font("Segoe UI", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkFlatLabel17.ForeColor = System.Drawing.Color.White;
            this.darkFlatLabel17.Location = new System.Drawing.Point(332, 9);
            this.darkFlatLabel17.Name = "darkFlatLabel17";
            this.darkFlatLabel17.Size = new System.Drawing.Size(198, 37);
            this.darkFlatLabel17.TabIndex = 8;
            this.darkFlatLabel17.Text = "Informations :";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // MysticINT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(53)))), ((int)(((byte)(66)))));
            this.ClientSize = new System.Drawing.Size(920, 485);
            this.Controls.Add(this.darkFlatTabControl1);
            this.Controls.Add(this.cxFlatStatusBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1920, 1050);
            this.Name = "MysticINT";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mystic | Clean & Privacy | Version : 1.6";
            this.darkFlatTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private CxFlatUI.CxFlatStatusBar cxFlatStatusBar1;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatTabControl darkFlatTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel4;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel6;
        private System.Windows.Forms.PictureBox pictureBox3;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel7;
        private System.Windows.Forms.PictureBox pictureBox4;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel1;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer1;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel8;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatButton darkFlatButton1;
        private CxFlatUI.CxFlatCheckBox cxFlatCheckBox2;
        private CxFlatUI.CxFlatCheckBox cxFlatCheckBox1;
        private CxFlatUI.CxFlatCheckBox cxFlatCheckBox3;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel9;
        private CxFlatUI.CxFlatCheckBox cxFlatCheckBox4;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel10;
        private CxFlatUI.CxFlatCheckBox cxFlatCheckBox5;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel11;
        private CxFlatUI.CxFlatCheckBox cxFlatCheckBox8;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel14;
        private CxFlatUI.CxFlatCheckBox cxFlatCheckBox7;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel13;
        private CxFlatUI.CxFlatCheckBox cxFlatCheckBox6;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel12;
        private System.Windows.Forms.PictureBox pictureBox6;
        private CxFlatUI.CxFlatCheckBox cxFlatCheckBox9;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel15;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel17;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TabPage tabPage4;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatButton darkFlatButton2;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel28;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel27;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel26;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel25;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel24;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel23;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel31;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel32;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel29;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel30;
        private System.Windows.Forms.Panel panel4;
        private CxFlatUI.CxFlatComboBox cxFlatComboBox1;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel33;
        private System.Windows.Forms.PictureBox pictureBox8;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel34;
        private System.Windows.Forms.TabPage tabPage5;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatButton darkFlatButton3;
        private CxFlatUI.CxFlatCheckBox cxFlatCheckBox10;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel35;
        private CxFlatUI.CxFlatTextArea cxFlatTextArea1;
        private System.Windows.Forms.PictureBox pictureBox9;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel36;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel16;
        private System.Windows.Forms.PictureBox pictureBox10;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel19;
        private Zeroit.Framework.UIThemes.DarkFlat.DarkFlatLabel darkFlatLabel18;
    }
}